/*
 * Condition.java
 *
 * Created on July 9, 2002, 4:42 PM
 */

package util;

/**
 *
 * @author  gcai
 */
public class SQLCondition {
    public String name;
    public String op = "=";
    public String value;
    public String join = "";
    
}
